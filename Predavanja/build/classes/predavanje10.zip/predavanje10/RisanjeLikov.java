/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package predavanje10;
import StdDraw;

/**
 *
 * @author Tim
 */
public class RisanjeLikov {
    StdDraw.setScale(-100, 100
            
    Lik[] liki = new Liki[100];
    Liki[0] = new Krog(10, 10. 5. Color.red);
    
    Liki[0].narisi();
}
